import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component Pages
import { UserComponent } from "./user/user.component";
import { ProductComponent } from './product/product.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { ProductAddComponent } from './product-add/product-add.component';

const routes: Routes = [
    {
        path: "users",
        component: UserComponent
    },
    {
      path: "products",
      component: ProductComponent
    },
    {
      path: "product-add",
      component: ProductAddComponent
    },
    {
      path: "productdetail/:id",
      component: ProductDetailComponent
    },
    {
      path: "userdetail",
      component: UserDetailComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AdministrationsRoutingModule { }
