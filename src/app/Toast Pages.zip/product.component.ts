import { Component, OnInit } from '@angular/core';
import { MyToastService } from '../my-toast-service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})

export class ProductComponent implements OnInit {
  breadCrumbItems!: Array<{}>;
  products: any = [];
  masterSelected!:boolean;
 
  constructor(    
    public myToastService: MyToastService
    
  ) {  }

  ngOnInit(): void {
    this.myToastService.show('Logged in Successfull.', { classname: 'bg-success text-center text-white', delay: 5000 });
  }

}
